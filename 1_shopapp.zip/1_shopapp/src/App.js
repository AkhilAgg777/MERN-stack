import React, { useState } from 'react';
import {SearchPage} from './containers/SearchPage';
import CommonContext from './utils/context';
let total = 0;


const App = (props)=>{
  console.log('App Render Call');

  const [plus, setPlus] = useState(0);
  const updateTotal = (val)=>{
    console.log('Val is ',val);
    total += val;
    //shareObject = { ...shareObject, total:total};
    shareObject.total = total;
    console.log('Total is ',shareObject);

    setPlus(plus+1);

  }
  const shareObject = {total:total, updateTotal:updateTotal};

  return (
    <div className='container'>
      <CommonContext.Provider value={shareObject}>
      <SearchPage/>
      </CommonContext.Provider>

    </div>
  );
}
export default App;