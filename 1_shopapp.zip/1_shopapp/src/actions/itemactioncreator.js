export const itemActionCreator = (data, name)=>{
    return {
        payload:{
           items:data
        },
        type:name
    }
}