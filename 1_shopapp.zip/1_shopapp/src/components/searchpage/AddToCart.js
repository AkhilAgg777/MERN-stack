import React, { useState } from 'react'
import CommonContext from '../../utils/context';
export const  Addtocart=(props)=> {
    const [cartValue, setCart] = useState(false);
    console.log('Add to Cart Call..... ',cartValue);

    let cartString = 'Cart Value is '+cartValue;
    const toggleCart=()=>{

        setCart(!cartValue);
            //console.log('Toggle Cart Call ',cartValue);
    }
    return (
        <>
        {/* {cartString} */}
        <CommonContext.Consumer>
            {
                (shareObject)=>{
                    return (
                        <button onClick={()=>{
                            shareObject.updateTotal(!cartValue?1:-1);
                            toggleCart();

                        }} className = 'btn btn-success'>{cartValue?'Remove From Cart':'Add to Cart'}</button>
                    )
                }
            }
        </CommonContext.Consumer>

        </>
    )
}
