import React from 'react'

export const Norecordfound=(props)=>{
    

    return (
        <>
          <h3>No Record Found,Need to search something else...</h3>  
        </>
    )
}
