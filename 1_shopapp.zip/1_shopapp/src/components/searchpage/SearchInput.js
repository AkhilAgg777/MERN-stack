import React from 'react';
export const SearchInput = React.memo((props)=>{
    return (
        <div className='form-group'>
            <label>Search</label>
            <input className='form-control' type='text' placeholder='Type to Search'/>
            <button className='btn btn-primary'>Search</button>
            </div>
    )
});