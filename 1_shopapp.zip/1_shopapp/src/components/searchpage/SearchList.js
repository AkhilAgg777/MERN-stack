import React from 'react'
import { NoRecordFound } from './NotRecordFound'
import { Norecordfound } from './NoRecordFound'
import {Item} from './Item';
import {connect} from 'react-redux';
export const  SearchList=(props)=> {
//{props.products.map((product,index)=><Item key={product.id}  product= {product}/>)}
let jsx = <NoRecordFound/>;
if(props.myitems){
         jsx = <>{props.myitems.map((product,index)=><Item key={product.id}  product= {product}/>)}</>;
    }

    return (
        <>
        {jsx}

        </>
    )
}
const mapStateToProps = (state)=>{
    console.log('State Items Rec and Set to Props ',state);
    return {
        'myitems':state.itemr.items
    }
}
export default connect(mapStateToProps)(SearchList);
//const hoc = connect(mapStateToProps);
//export const myComp =  hoc(SearchList);
