export const CONFIG = {
    //URL:'https://raw.githubusercontent.com/amitsrivastava4all/mern_jan/main/products.json'
    URL :'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/mobiles.json',
    ACTION_TYPES:{
        ADD:'ADD',
        LOAD:'LOAD'
    }
}