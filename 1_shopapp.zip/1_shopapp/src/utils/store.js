import {applyMiddleware, combineReducers, createStore} from 'redux';
import { ItemReducer } from '../helpers/itemreducer';
import { OrderReducer } from '../helpers/orderreducer';
import { LoggerMiddleWare } from './loggingmiddleware';
import thunk from 'redux-thunk';
//export const store = createStore(ItemReducer);
export const store = createStore(combineReducers({
    itemr: ItemReducer,order:OrderReducer
}),applyMiddleware(thunk,LoggerMiddleWare));
store.subscribe(()=>{
    console.log('State Updated... ',store.getState());
})