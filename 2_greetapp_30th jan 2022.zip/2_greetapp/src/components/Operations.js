import React from 'react';
export const Operations=(props)=>{
    return(
<>
<button onClick={props.click}>{props.title}</button>
</>
    );
}