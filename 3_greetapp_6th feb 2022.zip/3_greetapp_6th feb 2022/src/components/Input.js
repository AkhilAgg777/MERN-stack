import React from 'react';
export const Input=(props)=>{
    console.log('Input Call');
    let placeHolder=`Type ${props.title} Here`;
    return(
<>
<label>{props.title}</label>
<input onChange={props.change} type='text' placeholder={placeHolder}/>
</>
    )
}