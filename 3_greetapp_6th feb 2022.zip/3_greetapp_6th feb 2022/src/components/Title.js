import React from 'react';
export const Title=()=>{
    console.log('Title call');
    return (<h1>Greet App</h1>);
}