import { Title } from "../components/Title";
import React,{Component} from 'react';
import { Input } from "../components/Input";
import { Operations } from "../components/Operations";
import { Output } from "../components/Output";
export class Greet extends Component{
    constructor(){
        super();  //to call the parent constructor
        console.log('1. Init member variables');
        this.firstName='';
        this.lastName='';
        this.fullName='';
        this.state={msg:this.fullName};
    } 

    makeFullName(){
        this.fullName=this.initCap(this.firstName)+' '+this.initCap(this.lastName);
        console.log('Full Name is',this.fullName);
        //this.state.msg=this.fullname;  
        //this.setState(this.state);//mutable style
        this.setState({...this.state,msg:this.fullName});  //immutable style
    }
    takeFirstName(event){
console.log('I am called...',event.target.value);
this.firstName=event.target.value;
console.log("First Name",this.firstName);
    }
       takeLastName(event){
        console.log('I am called Last Name...',event.target.value);
        this.lastName=event.target.value;
        console.log("Last Name",this.lastName);
            }

            initCap(str){
            return str.charAt(0).toUpperCase()+str.substring(1).toLowerCase();
            }
    render(){
        console.log('2. Render Call');
        return(
            <div>
           <Title/>
            <Input change={this.takeFirstName.bind(this)} title="First Name"/>
            <br/>
            <Input change={this.takeLastName.bind(this)} title="Last Name"/>
            <br/>
            <Operations click={this.makeFullName.bind(this)} title="Greet"/>
           <Operations title="Clear All"/>
           <Output result={this.state.msg}/>
         </div>
        )
    }
}




// export const Greet=()=>{
//     return (
//         <div>
//            <Title/>
//            <Input title="First Name"/>
//            <br/>
//            <Input title="Last Name"/>
//            <br/>
//            <Operations title="Greet"/>
//            <Operations title="Clear All"/>
//            <Output result=''/>
//         </div>
//     )
// }