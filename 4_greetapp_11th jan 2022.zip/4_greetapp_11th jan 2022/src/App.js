import React from 'react';
import { Greet } from './containers/Greet';

const App=()=>{
  return (
    <Greet/>
  )
}
export default App;