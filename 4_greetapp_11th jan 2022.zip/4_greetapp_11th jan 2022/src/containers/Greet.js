import { Title } from "../components/Title";
import React, { Component } from 'react';
import { Input } from "../components/Input";
import { Operations } from "../components/Operations";
import { Output } from "../components/Output";
export class Greet extends Component {
    constructor() {
        super();  //to call the parent constructor
        console.log('1. Init member variables');
        this.firstName = '';
        this.lastName = '';
        this.fullName = '';
        this.state = { msg: this.fullName };
        //this.state = { msg: this.fullName,firstName:this.firstName,lastName:this.lastName };
        this.makeFullNamefn = this.makeFullName.bind(this);
    }

    clearAll() {
        this.firstName = "";
        this.lastName = "";
        this.setState({ ...this.state, msg: '' });
    }
    makeFullName() {
        this.fullName = this.initCap(this.firstName) + ' ' + this.initCap(this.lastName);
        console.log('Full Name is', this.fullName);
        //this.state.msg=this.fullname;  
        //this.setState(this.state);//mutable style
        this.setState({ ...this.state, msg: this.fullName });  //immutable style
    }
    takeFirstName(event) {
        console.log('I am called...', event.target.value);
        this.firstName = event.target.value;
        console.log("First Name", this.firstName);
        this.setState({ ...this.state });

        //another way to achieve above thing
        // this.setState({...this.state,'firstName':this.firstName});

    }
    takeLastName(event) {
        console.log('I am called Last Name...', event.target.value);
        this.lastName = event.target.value;
        this.setState({ ...this.state });
        console.log("Last Name", this.lastName);
    }

    initCap(str) {
        return str.charAt(0).toUpperCase() + str.substring(1).toLowerCase();
    }
    render() {
        console.log('2. Render Call');
        return (
            <div>
                <Title />
                <Input val={this.firstName} change={this.takeFirstName.bind(this)} title="First Name" />
                <br />
                <Input val={this.lastName} change={this.takeLastName.bind(this)} title="Last Name" />
                <br />

                <Operations cssClass='alert-info' click={this.makeFullName.bind(this)} title="Greet" />
                {/* //another way of achieving above thing
            <Operations cssClass='alert-info' click={this.makeFullNamefn} title="Greet"/> */}

                {/* //another way of achieving clear All
           <Operations cssClass='alert-warning' click-={this.clearAll.bind(this)} title="Clear All"/> */}
                <Operations cssClass='alert-warning' click={() => {
                    this.clearAll();
                }} title="Clear All" />
                <Output result={this.state.msg} />
            </div>
        )
    }
}




// export const Greet=()=>{
//     return (
//         <div>
//            <Title/>
//            <Input title="First Name"/>
//            <br/>
//            <Input title="Last Name"/>
//            <br/>
//            <Operations title="Greet"/>
//            <Operations title="Clear All"/>
//            <Output result=''/>
//         </div>
//     )
// }