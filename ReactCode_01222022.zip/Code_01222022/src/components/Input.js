import React from 'react';
export const Input=(props)=>{
    let placeHolder=`Type ${props.title} Here`;
    return(
<>
<label>{props.title}</label>
<input onChange={props.change} type='text' placeholder={placeHolder}/>
</>
    )
}