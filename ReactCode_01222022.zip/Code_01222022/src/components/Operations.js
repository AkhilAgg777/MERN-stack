import React from 'react';
export const Operations=(props)=>{
    return(
<>
<button>{props.title}</button>
</>
    );
}