import { Title } from "../components/Title";
import React,{Component} from 'react';
import { Input } from "../components/Input";
import { Operations } from "../components/Operations";
import { Output } from "../components/Output";
export class Greet extends Component{
    constructor(){
        super();  //to call the parent constructor
        this.firstName='';
        this.lastName='';
    }
    takeFirstName(event){
console.log('I am called...',event.target.value);
this.firstName=event.target.value;
console.log("First Name",this.firstName);
    }
       takeLastName(event){
        console.log('I am called Last Name...',event.target.value);
        this.lastName=event.target.value;
        console.log("Last Name",this.lastName);
            }
    render(){
        return(
            <div>
           <Title/>
            <Input change={this.takeFirstName.bind(this)} title="First Name"/>
            <br/>
            <Input change={this.takeLastName.bind(this)} title="Last Name"/>
            <br/>
            <Operations title="Greet"/>
           <Operations title="Clear All"/>
           <Output result=''/>
         </div>
        )
    }
}




// export const Greet=()=>{
//     return (
//         <div>
//            <Title/>
//            <Input title="First Name"/>
//            <br/>
//            <Input title="Last Name"/>
//            <br/>
//            <Operations title="Greet"/>
//            <Operations title="Clear All"/>
//            <Output result=''/>
//         </div>
//     )
// }